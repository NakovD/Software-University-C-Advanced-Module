﻿using System.Collections.Generic;
using System.Linq;

namespace DefiningClasses
{
    public class Family
    {
        private List<Person> people;

        public List<Person> People
        {
            get { return people; }
            set { people = value; }
        }

        public Family()
        {
            this.People = new List<Person>();
        }

        public void AddMember(Person member)
        {
            this.People.Add(member);
        }

        public Person GetOldestMember()
        {
            var sortedMembers = this.People.OrderByDescending(p => p.Age).ToList();
            var oldest = sortedMembers[0];

            return oldest;
        }
    }
}
