﻿using System;

namespace Date_Modifier
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var firstDate = Console.ReadLine();
            var secondDate = Console.ReadLine();
            var dateModif = new DateModifier();
            Console.WriteLine(dateModif.Calculate(firstDate, secondDate));
        }
    }

    public class DateModifier
    {
        public int Calculate(string _firstDate, string _secondDate)
        {
            var firstDateInfo = _firstDate.Split(" ", StringSplitOptions.RemoveEmptyEntries);
            var secondDateInfo = _secondDate.Split(" ", StringSplitOptions.RemoveEmptyEntries);
            var firstYear = int.Parse(firstDateInfo[0]);
            var firstMonth = int.Parse(firstDateInfo[1]);
            var firstDay = int.Parse(firstDateInfo[2]);
            var secondYear = int.Parse(secondDateInfo[0]);
            var secondMonth = int.Parse(secondDateInfo[1]);
            var secondDay = int.Parse(secondDateInfo[2]);

            var firstDate = new DateTime(firstYear, firstMonth, firstDay);
            var secondDate = new DateTime(secondYear, secondMonth, secondDay);

            var dateComparasion = firstDate.CompareTo(secondDate);

            TimeSpan result;

            if (dateComparasion > 0) result = firstDate - secondDate;
            else result = secondDate - firstDate;

            return result.Days;
        }
    }
}
