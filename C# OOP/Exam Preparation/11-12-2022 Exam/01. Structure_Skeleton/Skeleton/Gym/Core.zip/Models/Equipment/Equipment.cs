﻿namespace Gym.Models.Equipment
{
    using Gym.Models.Equipment.Contracts;

    public abstract class Equipment : IEquipment
    {
        public double Weight { get; private set; }

        public decimal Price { get; private set; }

        public Equipment(double weight, decimal price)
        {
            Weight = weight;
            Price = price;
        }
    }
}
