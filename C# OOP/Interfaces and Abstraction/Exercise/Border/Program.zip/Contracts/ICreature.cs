﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Border.Contracts
{
    public interface ICreature
    {
        public string Name { get; }
    }
}
