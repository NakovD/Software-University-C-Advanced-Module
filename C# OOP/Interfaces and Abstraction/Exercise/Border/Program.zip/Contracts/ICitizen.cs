﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Border.Contracts
{
    public interface ICitizen
    {
        public string Id { get; }
    }
}
