﻿namespace P01_HarvestingFields.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
