﻿namespace P02_BlackBoxInteger.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
