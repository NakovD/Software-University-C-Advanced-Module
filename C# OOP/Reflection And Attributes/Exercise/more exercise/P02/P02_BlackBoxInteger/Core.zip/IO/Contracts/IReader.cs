﻿namespace P02_BlackBoxInteger.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
